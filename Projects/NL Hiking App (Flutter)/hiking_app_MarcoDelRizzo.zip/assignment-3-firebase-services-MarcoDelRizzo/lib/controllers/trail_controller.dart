import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/trail_model.dart';

class TrailService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Trail>> watchTrails() {
    return _db.collection('trails').snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return Trail.fromFirestore(doc.id, doc.data());
      }).toList();
    });
  }
}

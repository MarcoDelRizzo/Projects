import 'dart:io' show File;
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:firebase_storage/firebase_storage.dart';
import '../models/image_upload_result.dart';

class StorageController {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  final List<String> allowedTypes = ['jpg', 'jpeg', 'png'];
  final int maxFileSize = 5 * 1024 * 1024; // 5MB

  // WEB VALIDATION
  void validateImageWeb(Uint8List bytes, String fileName) {
    final ext = fileName.split('.').last.toLowerCase();
    if (!allowedTypes.contains(ext)) {
      throw Exception("Only JPG, JPEG, PNG allowed.");
    }
    if (bytes.length > maxFileSize) {
      throw Exception("File too large (max 5MB).");
    }
  }

  // MOBILE VALIDATION
  void validateImageMobile(File file) {
    final ext = file.path.split('.').last.toLowerCase();
    if (!allowedTypes.contains(ext)) {
      throw Exception("Only JPG, JPEG, PNG allowed.");
    }
    if (file.lengthSync() > maxFileSize) {
      throw Exception("File too large (max 5MB).");
    }
  }

  Future<ImageUploadResult> uploadTrailImage({
    required dynamic file,
    required String trailId,
    required Function(double) onProgress,
  }) async {
    final ref = _storage.ref("trails/$trailId/main_photo.jpg");

    UploadTask uploadTask;

    if (kIsWeb) {
      final bytes = file['bytes'];
      final name = file['name'];

      validateImageWeb(bytes, name);

      uploadTask = ref.putData(
        bytes,
        SettableMetadata(contentType: "image/png"),
      );
    } else {
      final f = file as File;
      validateImageMobile(f);

      uploadTask = ref.putFile(
        f,
        SettableMetadata(contentType: "image/jpeg"),
      );
    }

    uploadTask.snapshotEvents.listen((event) {
      onProgress(event.bytesTransferred / event.totalBytes);
    });

    final snap = await uploadTask;
    final url = await snap.ref.getDownloadURL();

    return ImageUploadResult(downloadUrl: url, storagePath: ref.fullPath);
  }


  Future<ImageUploadResult> uploadUserHikePhoto({
    required dynamic file,
    required String userId,
    required String logId,
    required Function(double) onProgress,
  }) async {
    final ref = _storage.ref("users/$userId/hike_photos/$logId.jpg");

    UploadTask uploadTask;

    if (kIsWeb) {
      final bytes = file['bytes'];
      final name = file['name'];

      validateImageWeb(bytes, name);

      uploadTask = ref.putData(
        bytes,
        SettableMetadata(contentType: "image/png"),
      );
    } else {
      final f = file as File;
      validateImageMobile(f);

      uploadTask = ref.putFile(
        f,
        SettableMetadata(contentType: "image/jpeg"),
      );
    }

    uploadTask.snapshotEvents.listen((event) {
      onProgress(event.bytesTransferred / event.totalBytes);
    });

    final snap = await uploadTask;
    final url = await snap.ref.getDownloadURL();

    return ImageUploadResult(downloadUrl: url, storagePath: ref.fullPath);
  }
}

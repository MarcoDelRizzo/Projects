import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/hike_log_model.dart';

class HikeLogService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get _uid {
    final user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not logged in');
    }
    return user.uid;
  }

  CollectionReference<Map<String, dynamic>> get _logsCollection {
    return _db
        .collection('users')
        .doc(_uid)
        .collection('my_completed_hikes');
  }

  Stream<List<HikeLog>> watchLogs() {
    return _logsCollection
        .orderBy('date_completed', descending: true)
        .snapshots()
        .map((snapshot) {
      return snapshot.docs
          .map((doc) => HikeLog.fromFirestore(doc.id, doc.data()))
          .toList();
    });
  }

  Future<void> createLog({
    required String trailId,
    required String trailName,
    required DateTime dateCompleted,
    required String notes,
    required int rating,
    required String photoUrl, // <-- NEW
  }) async {
    final doc = _logsCollection.doc();

    final log = HikeLog(
      id: doc.id,
      trailId: trailId,
      trailName: trailName,
      dateCompleted: dateCompleted,
      notes: notes,
      rating: rating,
      photoUrl: photoUrl,
    );

    await doc.set(log.toMap());
  }

  Future<void> updateLog({
    required HikeLog existing,
    required String trailId,
    required String trailName,
    required DateTime dateCompleted,
    required String notes,
    required int rating,
    required String photoUrl,
  }) async {
    final updated = HikeLog(
      id: existing.id,
      trailId: trailId,
      trailName: trailName,
      dateCompleted: dateCompleted,
      notes: notes,
      rating: rating,
      photoUrl: photoUrl,
    );

    await _logsCollection.doc(existing.id).update(updated.toMap());
  }

  Future<void> deleteLog(String id) async {
    await _logsCollection.doc(id).delete();
  }
}

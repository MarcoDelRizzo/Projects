class Trail {
  final String id;
  final String name;
  final String location;
  final String difficulty;
  final double lengthKm;
  final String time;
  final String description;
  final String imageUrl; // optional, can be empty

  Trail({
    required this.id,
    required this.name,
    required this.location,
    required this.difficulty,
    required this.lengthKm,
    required this.time,
    required this.description,
    required this.imageUrl,
  });

  factory Trail.fromFirestore(String id, Map<String, dynamic> data) {
    return Trail(
      id: id,
      name: (data['name'] ?? '').toString(),
      location: (data['location'] ?? '').toString(),
      difficulty: (data['difficulty'] ?? '').toString(),
      time: (data['time'] ?? '').toString(),
      description: (data['description'] ?? '').toString(),
      lengthKm: (data['length_km'] is num)
          ? (data['length_km'] as num).toDouble()
          : 0.0,
      imageUrl: (data['image_url'] ?? '').toString(),
    );
  }
}

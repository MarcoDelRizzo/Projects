class ImageUploadResult {
  final String downloadUrl;
  final String storagePath;

  ImageUploadResult({
    required this.downloadUrl,
    required this.storagePath,
  });
}

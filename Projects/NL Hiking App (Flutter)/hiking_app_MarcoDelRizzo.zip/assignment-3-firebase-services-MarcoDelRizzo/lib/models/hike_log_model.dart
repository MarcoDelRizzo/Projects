class HikeLog {
  final String id;
  final String trailId;
  final String trailName;
  final DateTime dateCompleted;
  final String notes;
  final int rating;
  final String photoUrl;

  HikeLog({
    required this.id,
    required this.trailId,
    required this.trailName,
    required this.dateCompleted,
    required this.notes,
    required this.rating,
    required this.photoUrl,
  });

  factory HikeLog.fromFirestore(String id, Map<String, dynamic> data) {
    final timestamp = data['date_completed'];
    final DateTime date = timestamp != null
        ? DateTime.fromMillisecondsSinceEpoch(
            (timestamp.millisecondsSinceEpoch),
          )
        : DateTime.now();

    return HikeLog(
      id: id,
      trailId: (data['trail_id'] ?? '').toString(),
      trailName: (data['trail_name'] ?? '').toString(),
      dateCompleted: date,
      notes: (data['notes'] ?? '').toString(),
      rating: data['rating'] is int ? data['rating'] as int : 0,
      photoUrl: (data['photo_url'] ?? '').toString(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'trail_id': trailId,
      'trail_name': trailName,
      'date_completed': dateCompleted,
      'notes': notes,
      'rating': rating,
      'photo_url': photoUrl,
    };
  }
}

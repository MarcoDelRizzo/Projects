class StorageUrlFix {
  static String fix(String url) {
    if (url.isEmpty) return url;

    if (url.contains("hiking-app-marco.firebasestorage.app")) {
      return url;
    }

    try {
      final uri = Uri.parse(url);
      final path = uri.pathSegments.last;
      final token = uri.queryParameters["token"];
      return "https://hiking-app-marco.firebasestorage.app/o/$path?alt=media&token=$token";
    } catch (_) {
      return url;
    }
  }
}

import 'dart:io' show File;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:typed_data';
import '../controllers/storage_controller.dart';
import '../utils/storage_url_fix.dart';

class ImageUploadWidget extends StatefulWidget {
  final String uploadPathType; // "trail" or "log"
  final String id;
  final String? userId;
  final Function(String) onUploaded;

  const ImageUploadWidget({
    super.key,
    required this.uploadPathType,
    required this.id,
    required this.onUploaded,
    this.userId,
  });

  @override
  State<ImageUploadWidget> createState() => _ImageUploadWidgetState();
}

class _ImageUploadWidgetState extends State<ImageUploadWidget> {
  final ImagePicker _picker = ImagePicker();
  final StorageController _storage = StorageController();

  Uint8List? _previewBytes;
  bool _uploading = false;
  double _progress = 0;

  Future<void> pickImage() async {
    final picked = await _picker.pickImage(source: ImageSource.gallery);
    if (picked == null) return;

    dynamic fileData;

    if (kIsWeb) {
      final bytes = await picked.readAsBytes();
      _previewBytes = bytes;
      fileData = {"bytes": bytes, "name": picked.name};
    } else {
      final file = File(picked.path);
      _previewBytes = await picked.readAsBytes();
      fileData = file;
    }

    setState(() {
      _uploading = true;
      _progress = 0;
    });

    try {
      final result = widget.uploadPathType == "trail"
          ? await _storage.uploadTrailImage(
              file: fileData,
              trailId: widget.id,
              onProgress: (p) => setState(() => _progress = p),
            )
          : await _storage.uploadUserHikePhoto(
              file: fileData,
              userId: widget.userId!,
              logId: widget.id,
              onProgress: (p) => setState(() => _progress = p),
            );

      final cleanUrl = StorageUrlFix.fix(result.downloadUrl);
      widget.onUploaded(cleanUrl);
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Upload error: $e")));
    } finally {
      setState(() => _uploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ElevatedButton.icon(
          icon: const Icon(Icons.photo),
          label: const Text("Select Photo"),
          onPressed: pickImage,
        ),

        if (_previewBytes != null) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.memory(
              _previewBytes!,
              height: 160,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
        ],

        if (_uploading) ...[
          const SizedBox(height: 10),
          LinearProgressIndicator(value: _progress),
        ],
      ],
    );
  }
}

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';

import 'views/auth_view.dart';
import 'views/home_view.dart';
import 'views/trails_view.dart';
import 'views/hike_log_view.dart';

class GoRouterRefreshStream extends ChangeNotifier {
  GoRouterRefreshStream(Stream<dynamic> stream) {
    _subscription = stream.asBroadcastStream().listen((_) {
      notifyListeners();
    });
  }

  late final StreamSubscription<dynamic> _subscription;

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }
}

class AppRouter {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  GoRouter get router => GoRouter(
        initialLocation: '/auth',

        refreshListenable: GoRouterRefreshStream(_auth.authStateChanges()),

        redirect: (context, state) {
          final user = _auth.currentUser;
          final goingToAuth = state.matchedLocation == '/auth';

          if (user == null && !goingToAuth) {
            return '/auth';
          }

          if (user != null && goingToAuth) {
            return '/home';
          }

          return null;
        },

        routes: [
          GoRoute(
            path: '/auth',
            builder: (context, state) => const AuthView(),
          ),

          GoRoute(
            path: '/home',
            builder: (context, state) => const HomeView(),
          ),

          GoRoute(
            path: '/trails',
            builder: (context, state) => const TrailsView(),
          ),

          GoRoute(
            path: '/logs',
            builder: (context, state) => const HikeLogsView(),
          ),
        ],
      );
}

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart' as fb_auth;
import 'package:firebase_ui_auth/firebase_ui_auth.dart' as fb_ui;

class AuthView extends StatelessWidget {
  const AuthView({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // BACKGROUND GRADIENT
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF1F3D1E),
                Color(0xFF2E5530),
                Color(0xFF4F7A52),
              ],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),

        // CENTERED AUTH CARD
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 500),
            child: Card(
              elevation: 10,
              color: Colors.white.withOpacity(0.92),
              margin: const EdgeInsets.all(24),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),

                // FIREBASE UI LOGIN SCREEN
                child: fb_ui.SignInScreen(
                  providers: [
                    fb_ui.EmailAuthProvider(),
                  ],

                  // HEADER (NO OVERFLOW)
                  headerBuilder: (context, constraints, _) {
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.terrain,
                              size: 60,
                              color: Color(0xFF2E5530),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              'NL Hikes',
                              style: TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF2E5530),
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Explore Newfoundland like never before',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.black54,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      ),
                    );
                  },

                  // FOOTER
                  footerBuilder: (context, _) {
                    return Padding(
                      padding: const EdgeInsets.only(top: 12, bottom: 8),
                      child: Column(
                        children: [
                          Text(
                            'Log hikes • Upload photos • Track progress',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ],
                      ),
                    );
                  },

                  // FORGOT PASSWORD ACTION (CUSTOM, WORKING)
                  actions: [
                    fb_ui.ForgotPasswordAction((context, email) async {
                      final controller =
                      TextEditingController(text: email ?? '');

                      await showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: const Text("Reset Password"),
                            content: TextField(
                              controller: controller,
                              decoration: const InputDecoration(
                                labelText: "Email",
                              ),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(context),
                                child: const Text("Cancel"),
                              ),
                              TextButton(
                                onPressed: () async {
                                  try {
                                    await fb_auth.FirebaseAuth.instance
                                        .sendPasswordResetEmail(
                                      email: controller.text.trim(),
                                    );

                                    Navigator.pop(context);

                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(
                                        content: Text(
                                          "Password reset email sent! Check your inbox.",
                                        ),
                                      ),
                                    );
                                  } catch (e) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text("Error: $e"),
                                      ),
                                    );
                                  }
                                },
                                child: const Text("Send"),
                              ),
                            ],
                          );
                        },
                      );
                    }),
                  ],

                  // DESKTOP SIDE PANEL
                  sideBuilder: (context, constraints) {
                    if (constraints.maxWidth < 900) {
                      return const SizedBox.shrink();
                    }

                    return Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Color(0xFF1E4022),
                            Color(0xFF2F5732),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(40),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(
                                Icons.forest,
                                size: 150,
                                color: Colors.white70,
                              ),
                              const SizedBox(height: 24),
                              const Text(
                                'Welcome to NL Hikes',
                                style: TextStyle(
                                  fontSize: 42,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'Discover stunning trails across\nNewfoundland & Labrador.',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 20,
                                  color: Colors.white70,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

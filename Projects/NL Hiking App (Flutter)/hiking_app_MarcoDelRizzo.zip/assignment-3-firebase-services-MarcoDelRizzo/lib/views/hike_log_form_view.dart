import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../controllers/hike_log_controller.dart';
import '../controllers/trail_controller.dart';
import '../models/hike_log_model.dart';
import '../models/trail_model.dart';
import '../widgets/image_upload_widget.dart';

class HikeLogFormView extends StatefulWidget {
  final HikeLog? existingLog;
  const HikeLogFormView({super.key, this.existingLog});

  @override
  State<HikeLogFormView> createState() => _HikeLogFormViewState();
}

class _HikeLogFormViewState extends State<HikeLogFormView> {
  final HikeLogService _logService = HikeLogService();
  final TrailService _trailService = TrailService();
  final TextEditingController _notesController = TextEditingController();

  DateTime? _dateCompleted;
  String? _selectedTrailId;
  String? _selectedTrailName;
  int _rating = 3;
  String? _uploadedPhotoUrl;

  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final existing = widget.existingLog;

    if (existing != null) {
      _notesController.text = existing.notes;
      _dateCompleted = existing.dateCompleted;
      _selectedTrailId = existing.trailId;
      _selectedTrailName = existing.trailName;
      _rating = existing.rating;
      _uploadedPhotoUrl = existing.photoUrl;
    }
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dateCompleted ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (picked != null) {
      setState(() => _dateCompleted = picked);
    }
  }

  Future<void> _saveLog() async {
    if (_selectedTrailId == null || _selectedTrailName == null) return;
    if (_dateCompleted == null) return;

    setState(() => _saving = true);
    final notes = _notesController.text.trim();

    try {
      if (widget.existingLog == null) {
        await _logService.createLog(
          trailId: _selectedTrailId!,
          trailName: _selectedTrailName!,
          dateCompleted: _dateCompleted!,
          notes: notes,
          rating: _rating,
          photoUrl: _uploadedPhotoUrl ?? "",
        );
      } else {
        await _logService.updateLog(
          existing: widget.existingLog!,
          trailId: _selectedTrailId!,
          trailName: _selectedTrailName!,
          dateCompleted: _dateCompleted!,
          notes: notes,
          rating: _rating,
          photoUrl: _uploadedPhotoUrl ?? widget.existingLog!.photoUrl,
        );
      }

      if (mounted) Navigator.of(context).pop();
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existingLog != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? "Edit Hike Log" : "New Hike Log"),
      ),

      body: StreamBuilder<List<Trail>>(
        stream: _trailService.watchTrails(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final trails = snapshot.data!;
          if (_selectedTrailId == null && trails.isNotEmpty) {
            _selectedTrailId = trails.first.id;
            _selectedTrailName = trails.first.name;
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                // TITLE
                Text(
                  "Hike Log Details",
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 20),

                // TRAIL SELECTION
                _SectionCard(
                  title: "Trail",
                  child: DropdownButtonFormField<String>(
                    decoration: const InputDecoration(labelText: "Select Trail"),
                    value: _selectedTrailId,
                    items: trails.map((t) {
                      return DropdownMenuItem(
                        value: t.id,
                        child: Text(t.name),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedTrailId = value;
                        final trail = trails.firstWhere((t) => t.id == value);
                        _selectedTrailName = trail.name;
                      });
                    },
                  ),
                ),

                const SizedBox(height: 20),

                // DATE
                _SectionCard(
                  title: "Date Completed",
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _dateCompleted == null
                              ? "No date selected"
                              : _dateCompleted!.toLocal().toString().split(' ')[0],
                          style: const TextStyle(fontSize: 16),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: _pickDate,
                        child: const Text("Pick Date"),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // RATING
                _SectionCard(
                  title: "Rating",
                  child: DropdownButtonFormField<int>(
                    decoration: const InputDecoration(labelText: "Rate your hike"),
                    value: _rating,
                    items: List.generate(
                      5,
                          (i) => DropdownMenuItem(value: i + 1, child: Text("${i + 1} Stars")),
                    ),
                    onChanged: (v) => setState(() => _rating = v!),
                  ),
                ),

                const SizedBox(height: 20),

                // NOTES
                _SectionCard(
                  title: "Notes",
                  child: TextField(
                    controller: _notesController,
                    maxLines: 4,
                    maxLength: 200,
                    decoration: const InputDecoration(
                      hintText: "Describe your experience...",
                    ),
                  ),
                ),

                const SizedBox(height: 20),

                // PHOTO UPLOAD
                _SectionCard(
                  title: "Photo",
                  child: ImageUploadWidget(
                    uploadPathType: "log",
                    id: widget.existingLog?.id ?? "temp",
                    userId: FirebaseAuth.instance.currentUser!.uid,
                    onUploaded: (url) {
                      setState(() => _uploadedPhotoUrl = url);
                    },
                  ),
                ),

                const SizedBox(height: 28),

                // SAVE BUTTON
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saving ? null : _saveLog,
                    child: Text(_saving
                        ? "Saving..."
                        : isEditing
                        ? "Update Log"
                        : "Create Log"),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// Reusable section container
class _SectionCard extends StatelessWidget {
  final String title;
  final Widget child;
  const _SectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            child,
          ],
        ),
      ),
    );
  }
}

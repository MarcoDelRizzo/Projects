import 'package:flutter/material.dart';
import '../controllers/trail_controller.dart';
import '../models/trail_model.dart';
import '../widgets/trail_card.dart';

class TrailsView extends StatefulWidget {
  const TrailsView({super.key});

  @override
  State<TrailsView> createState() => _TrailsViewState();
}

class _TrailsViewState extends State<TrailsView> {
  final TrailService _service = TrailService();

  String? difficultyFilter;
  String sortMode = 'length';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("NL Hiking Trails")),

      body: Column(
        children: [
          // FILTER BAR
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                DropdownButton<String>(
                  value: difficultyFilter,
                  hint: const Text("Filter Difficulty"),
                  items: ['Easy', 'Moderate', 'Hard']
                      .map((d) => DropdownMenuItem(
                    value: d,
                    child: Text(d),
                  ))
                      .toList(),
                  onChanged: (v) => setState(() => difficultyFilter = v),
                ),
                const SizedBox(width: 12),

                DropdownButton<String>(
                  value: sortMode,
                  items: const [
                    DropdownMenuItem(
                      value: 'length',
                      child: Text("Sort: Length"),
                    ),
                    DropdownMenuItem(
                      value: 'time',
                      child: Text("Sort: Time"),
                    ),
                  ],
                  onChanged: (v) => setState(() => sortMode = v!),
                ),
              ],
            ),
          ),

          // MAIN CONTENT
          Expanded(
            child: StreamBuilder<List<Trail>>(
              stream: _service.watchTrails(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return _ErrorState();
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return _LoadingState();
                }

                if (!snapshot.hasData ||
                    snapshot.data == null ||
                    snapshot.data!.isEmpty) {
                  return _EmptyState();
                }

                var trails = snapshot.data!;

                if (difficultyFilter != null) {
                  trails = trails
                      .where((t) => t.difficulty == difficultyFilter)
                      .toList();
                }

                if (sortMode == 'length') {
                  trails.sort((a, b) => a.lengthKm.compareTo(b.lengthKm));
                } else {
                  trails.sort((a, b) => a.time.compareTo(b.time));
                }

                return ListView.builder(
                  itemCount: trails.length,
                  itemBuilder: (context, i) {
                    return TrailCard(trail: trails[i]);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _LoadingState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircularProgressIndicator(),
            const SizedBox(height: 12),
            Text("Loading trails...",
                style: TextStyle(color: Colors.grey.shade600)),
          ],
        ));
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.landscape_outlined, size: 60, color: Colors.grey.shade400),
            const SizedBox(height: 16),
            const Text("No trails found.", style: TextStyle(fontSize: 18)),
          ],
        ));
  }
}

class _ErrorState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 60, color: Colors.red.shade300),
            const SizedBox(height: 16),
            const Text("Error loading trails",
                style: TextStyle(fontSize: 18, color: Colors.red)),
          ],
        ));
  }
}

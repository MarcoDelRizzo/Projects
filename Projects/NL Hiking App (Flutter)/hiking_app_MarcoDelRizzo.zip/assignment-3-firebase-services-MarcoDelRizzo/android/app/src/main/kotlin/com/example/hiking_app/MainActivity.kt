package com.example.hiking_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
